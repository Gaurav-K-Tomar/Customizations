import $ from 'jquery';

export default function() {
    $("#product-listing-container .productGrid .product").slice(0, 21).css('display','inline-block');
    $("#loadMore").on('click', function (e) {
        e.preventDefault();
        $("#product-listing-container .productGrid .product:hidden").slice(0, 21).css('display','inline-block').slideDown();
        if ($("#product-listing-container .productGrid .product:hidden").length == 0) {
                $("#loadMore").fadeOut();
                $('#product-listing-container .pagination').show();
        }else{
                $("#loadMore").fadeIn();
                //$('#product-listing-container .pagination').hide();
        }
    });
    if ($("#product-listing-container .productGrid .product").length > 12) {
        $("#loadMore").fadeIn();
    }else{
        $("#loadMore").fadeOut();
        $('#product-listing-container .pagination').show();
    }
    console.log('loadMore JS')
}
