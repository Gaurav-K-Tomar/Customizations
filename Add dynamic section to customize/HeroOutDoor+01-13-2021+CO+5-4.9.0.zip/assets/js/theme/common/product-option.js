import utils from '@bigcommerce/stencil-utils';
export default class ProductOption {
    init() {
        this.bindEvents();
    }

    bindEvents() {
        if ($('.more_option_value').length) {
            let productoptionvalue = $.trim($('.more_option_value').text()).split(',');
            $(".product_more_option_dt").empty();
            for (let i = 0; i < productoptionvalue.length; i++) {
                
                utils.api.product.getById(productoptionvalue[i], {template: "custom/product-option-file"}, (err, resp) => {
                    var price = $(resp).find('.price--main').text();
                    var product_title = $(resp).find('.card-title').text();
                    var stock = $(resp).find('.stock-msg').text();
                    var pageLink = $(resp).find('.card-figure .product-image a').attr("href");
                    var product_image = $(resp).find('.card-figure .product-image a').html();
                    var stock = stock.replace( /\s/g, '');
                    if(stock=='outofstock'){
                        var cls = 'out-of-stock';
                    }else{
                       var cls = '';
                    }
                   
                    var htmlData = '<div class="productoption '+cls+'">'
                    +'<a href="'+pageLink+'">'
                    +product_image+product_title
                    +'<span>'+price+'</span>'
                    +'</a></div>';
                    $(".product_more_option_dt").append(htmlData);
                    
                    return false;
                });
            }
            
            
            
        }
        $(document).ajaxStop(function () {
            $('.product_more_option .loadingOverlay').remove();
            //mousehoverimage();
        });

        function mousehoverimage() {
            $('img.product-image').hover(function () {
                let title_get = $(this).attr('alt');
                let price = $(this).parent().parent().next().find('.price--main').text();
                $('.more-option-title .title').empty().append(title_get);
                $('.more-option-title .price').empty().append(price);
            }, function () {
                $('.more-option-title .title').empty();
                $('.more-option-title .price').empty();
            });

        }
    }

}
